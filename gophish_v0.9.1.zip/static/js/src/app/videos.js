/* videos.js
   Video Management (list, upload, delete, preview)
   Follows the same jQuery/api.* pattern as templates.js and landing_pages.js
*/

var videos = [];

function escapeHtml(s) {
  if (!s) return '';
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function showLoading(show) {
  if (show) {
    $("#videos-table").hide();
    $("#loading").show();
  } else {
    $("#loading").hide();
    $("#videos-table").show();
  }
}

/* === List === */
function loadVideos() {
  $("#emptyMessage").hide();
  showLoading(true);
  api.videos.get()
    .success(function (data) {
      if (!Array.isArray(data)) {
        errorFlash("Unexpected response from server.");
        showLoading(false);
        return;
      }
      videos = data;
      renderVideos();
      showLoading(false);
    })
    .error(function (xhr) {
      showLoading(false);
      if (xhr.status === 401) {
        errorFlash("Unauthorized. Please refresh and sign in again.");
      } else {
        errorFlash("Error fetching videos");
      }
    });
}

function renderVideos() {
  var $tbody = $("#videos-body");
  $tbody.empty();
  if (!videos || videos.length === 0) {
    $("#videos-table").show();
    $("#emptyMessage").show();
    return;
  }
  videos.forEach(function(v, i){
    var tr = [
      "<tr>",
      "<td>", escapeHtml(v.name), "</td>",
      "<td>", escapeHtml(v.description || ""), "</td>",
      "<td>", v.modified_date ? moment(v.modified_date).format('MMMM Do YYYY, h:mm:ss a') : "", "</td>",
      "<td class='text-right'>",
        "<button class='btn btn-primary btn-xs' data-toggle='tooltip' title='Preview' onclick='previewVideo(", v.id, ")'>",
          "<i class='fa fa-play'></i>",
        "</button> ",
        "<button class='btn btn-danger btn-xs' data-toggle='tooltip' title='Delete' onclick='deleteVideo(", i, ")'>",
          "<i class='fa fa-trash-o'></i>",
        "</button>",
      "</td>",
      "</tr>"
    ].join("");
    $tbody.append(tr);
  });
  $('[data-toggle="tooltip"]').tooltip();
}

/* === Preview ===
   Note: streaming is served from admin route /videos/stream/{id}
*/
function previewVideo(id) {
  $("#preview-src").attr("src", "/videos/stream/" + id);
  var v = document.getElementById("preview-video");
  if (v) { v.load(); }
  $("#previewModal").modal("show");
}

/* === Delete === */
function deleteVideo(idx) {
  var vid = videos[idx];
  Swal.fire({
    title: "Are you sure?",
    text: "This will delete the video. This can't be undone!",
    type: "warning",
    animation: false,
    showCancelButton: true,
    confirmButtonText: "Delete " + escapeHtml(vid.name),
    confirmButtonColor: "#428bca",
    reverseButtons: true,
    allowOutsideClick: false,
    preConfirm: function () {
      return new Promise(function (resolve, reject) {
        api.videoId.delete(vid.id)
          .success(function(){ resolve(); })
          .error(function(xhr){
            var msg = (xhr.responseJSON && xhr.responseJSON.message) || "Delete failed";
            reject(msg);
          });
      });
    }
  }).then(function (result) {
    if (result.value){
      Swal.fire('Video Deleted!', 'The video has been deleted!', 'success');
      loadVideos();
    }
  });
}

/* === Upload === */
function wireUploadForm() {
  $("#video-upload-form").on("submit", function (e) {
    e.preventDefault();
    var fd = new FormData(this);

    // ensure checkbox value is sent as a predictable string
    fd.set("is_public", $("#video-public").prop("checked") ? "true" : "false");

    showLoading(true);
    api.videos.post(fd)
      .success(function () {
        $("#uploadModal").modal("hide");
        $("#video-upload-form")[0].reset();
        successFlash("Video uploaded successfully!");
        loadVideos();
      })
      .error(function (xhr) {
        showLoading(false);
        var msg = (xhr.responseJSON && xhr.responseJSON.message) || "Upload failed";
        modalError(msg);
      });
  });
}

/* === init === */
$(document).ready(function(){
  // Ensure upload form wired and page loads videos
  wireUploadForm();
  loadVideos();
});

