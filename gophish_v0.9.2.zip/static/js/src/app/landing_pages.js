/*
	landing_pages.js
	Handles the creation, editing, and deletion of landing pages
	Author: Jordan Wright <github.com/jordan-wright>
*/
var pages = []


// Save attempts to POST to /templates/
function save(idx) {
    var page = {}
    page.name = $("#name").val()
    editor = CKEDITOR.instances["html_editor"]
    page.html = editor.getData()
    page.capture_credentials = $("#capture_credentials_checkbox").prop("checked")
    page.capture_passwords = $("#capture_passwords_checkbox").prop("checked")
    page.redirect_url = $("#redirect_url_input").val()
    if (idx != -1) {
        page.id = pages[idx].id
        api.pageId.put(page)
            .success(function (data) {
                successFlash("Page edited successfully!")
                load()
                dismiss()
            })
    } else {
        // Submit the page
        api.pages.post(page)
            .success(function (data) {
                successFlash("Page added successfully!")
                load()
                dismiss()
            })
            .error(function (data) {
                modalError(data.responseJSON.message)
            })
    }
}

function dismiss() {
    $("#modal\\.flashes").empty()
    $("#name").val("")
    $("#html_editor").val("")
    $("#url").val("")
    $("#redirect_url_input").val("")
    $("#modal").find("input[type='checkbox']").prop("checked", false)
    $("#capture_passwords").hide()
    $("#redirect_url").hide()
    $("#modal").modal('hide')
}

var deletePage = function (idx) {
    Swal.fire({
        title: "Are you sure?",
        text: "This will delete the landing page. This can't be undone!",
        type: "warning",
        animation: false,
        showCancelButton: true,
        confirmButtonText: "Delete " + escapeHtml(pages[idx].name),
        confirmButtonColor: "#428bca",
        reverseButtons: true,
        allowOutsideClick: false,
        preConfirm: function () {
            return new Promise(function (resolve, reject) {
                api.pageId.delete(pages[idx].id)
                    .success(function (msg) {
                        resolve()
                    })
                    .error(function (data) {
                        reject(data.responseJSON.message)
                    })
            })
        }
    }).then(function (result) {
        if (result.value){
            Swal.fire(
                'Landing Page Deleted!',
                'This landing page has been deleted!',
                'success'
            );
        }
        $('button:contains("OK")').on('click', function () {
            location.reload()
        })
    })
}

function importSite() {
    url = $("#url").val()
    if (!url) {
        modalError("No URL Specified!")
    } else {
        api.clone_site({
                url: url,
                include_resources: false
            })
            .success(function (data) {
                $("#html_editor").val(data.html)
                CKEDITOR.instances["html_editor"].setMode('wysiwyg')
                $("#importSiteModal").modal("hide")
            })
            .error(function (data) {
                modalError(data.responseJSON.message)
            })
    }
}

function edit(idx) {
    $("#modalSubmit").unbind('click').click(function () {
        save(idx)
    })
    $("#html_editor").ckeditor()
    setupAutocomplete(CKEDITOR.instances["html_editor"])
    var page = {}
    if (idx != -1) {
        $("#modalLabel").text("Edit Landing Page")
        page = pages[idx]
        $("#name").val(page.name)
        $("#html_editor").val(page.html)
        $("#capture_credentials_checkbox").prop("checked", page.capture_credentials)
        $("#capture_passwords_checkbox").prop("checked", page.capture_passwords)
        $("#redirect_url_input").val(page.redirect_url)
        if (page.capture_credentials) {
            $("#capture_passwords").show()
            $("#redirect_url").show()
        }
    } else {
        $("#modalLabel").text("New Landing Page")
    }
}

function copy(idx) {
    $("#modalSubmit").unbind('click').click(function () {
        save(-1)
    })
    $("#html_editor").ckeditor()
    var page = pages[idx]
    $("#name").val("Copy of " + page.name)
    $("#html_editor").val(page.html)
}

function load() {
    /*
        load() - Loads the current pages using the API
    */
    $("#pagesTable").hide()
    $("#emptyMessage").hide()
    $("#loading").show()
    api.pages.get()
        .success(function (ps) {
            pages = ps
            $("#loading").hide()
            if (pages.length > 0) {
                $("#pagesTable").show()
                pagesTable = $("#pagesTable").DataTable({
                    destroy: true,
                    columnDefs: [{
                        orderable: false,
                        targets: "no-sort"
                    }]
                });
                pagesTable.clear()
                pageRows = []
                $.each(pages, function (i, page) {
                    pageRows.push([
                        escapeHtml(page.name),
                        moment(page.modified_date).format('MMMM Do YYYY, h:mm:ss a'),
                        "<div class='pull-right'><span data-toggle='modal' data-backdrop='static' data-target='#modal'><button class='btn btn-primary' data-toggle='tooltip' data-placement='left' title='Edit Page' onclick='edit(" + i + ")'>\
                    <i class='fa fa-pencil'></i>\
                    </button></span>\
		    <span data-toggle='modal' data-target='#modal'><button class='btn btn-primary' data-toggle='tooltip' data-placement='left' title='Copy Page' onclick='copy(" + i + ")'>\
                    <i class='fa fa-copy'></i>\
                    </button></span>\
                    <button class='btn btn-danger' data-toggle='tooltip' data-placement='left' title='Delete Page' onclick='deletePage(" + i + ")'>\
                    <i class='fa fa-trash-o'></i>\
                    </button></div>"
                    ])
                })
                pagesTable.rows.add(pageRows).draw()
                $('[data-toggle="tooltip"]').tooltip()
            } else {
                $("#emptyMessage").show()
            }
        })
        .error(function () {
            $("#loading").hide()
            errorFlash("Error fetching pages")
        })
}

$(document).ready(function () {
    // Setup multiple modals
    // Code based on http://miles-by-motorcycle.com/static/bootstrap-modal/index.html
    $('.modal').on('hidden.bs.modal', function (event) {
        $(this).removeClass('fv-modal-stack');
        $('body').data('fv_open_modals', $('body').data('fv_open_modals') - 1);
    });
    $('.modal').on('shown.bs.modal', function (event) {
        // Keep track of the number of open modals
        if (typeof ($('body').data('fv_open_modals')) == 'undefined') {
            $('body').data('fv_open_modals', 0);
        }
        // if the z-index of this modal has been set, ignore.
        if ($(this).hasClass('fv-modal-stack')) {
            return;
        }
        $(this).addClass('fv-modal-stack');
        // Increment the number of open modals
        $('body').data('fv_open_modals', $('body').data('fv_open_modals') + 1);
        // Setup the appropriate z-index
        $(this).css('z-index', 1040 + (10 * $('body').data('fv_open_modals')));
        $('.modal-backdrop').not('.fv-modal-stack').css('z-index', 1039 + (10 * $('body').data('fv_open_modals')));
        $('.modal-backdrop').not('fv-modal-stack').addClass('fv-modal-stack');
    });
    $.fn.modal.Constructor.prototype.enforceFocus = function () {
        $(document)
            .off('focusin.bs.modal') // guard against infinite focus loop
            .on('focusin.bs.modal', $.proxy(function (e) {
                if (
                    this.$element[0] !== e.target && !this.$element.has(e.target).length
                    // CKEditor compatibility fix start.
                    &&
                    !$(e.target).closest('.cke_dialog, .cke').length
                    // CKEditor compatibility fix end.
                ) {
                    this.$element.trigger('focus');
                }
            }, this));
    };
    // Scrollbar fix - https://stackoverflow.com/questions/19305821/multiple-modals-overlay
    $(document).on('hidden.bs.modal', '.modal', function () {
        $('.modal:visible').length && $(document.body).addClass('modal-open');
    });
    $('#modal').on('hidden.bs.modal', function (event) {
        dismiss()
    });
    $("#capture_credentials_checkbox").change(function () {
        $("#capture_passwords").toggle()
        $("#redirect_url").toggle()
    })
    CKEDITOR.on('dialogDefinition', function (ev) {
        // Take the dialog name and its definition from the event data.
        var dialogName = ev.data.name;
        var dialogDefinition = ev.data.definition;

        // Check if the definition is from the dialog window you are interested in (the "Link" dialog window).
        if (dialogName == 'link') {
            dialogDefinition.minWidth = 500
            dialogDefinition.minHeight = 100

            // Remove the linkType field
            var infoTab = dialogDefinition.getContents('info');
            infoTab.get('linkType').hidden = true;
        }
    });

    load()
})

/* === Video Picker Integration for Landing Pages === */

// 호출: "Insert Training Video" 버튼 클릭 시
function showVideoPicker() {
    // Open modal and load videos
    $("#videoPickerModal").modal("show");
    loadVideoPicker();
}

function loadVideoPicker() {
    $("#videoPickerLoading").show();
    $("#videoPickerTable").hide();
    $("#videoPickerEmpty").hide();
    $("#videoPickerTable tbody").empty();

    api.videos.get()
        .success(function (videos) {
            $("#videoPickerLoading").hide();
            if (!Array.isArray(videos) || videos.length === 0) {
                $("#videoPickerEmpty").show();
                return;
            }
            $("#videoPickerTable").show();
            videos.forEach(function (v) {
                var row = $("<tr>");
                row.append($("<td>").text(v.name));
                row.append($("<td>").text(v.description || ""));
                var uploaded = v.modified_date ? moment(v.modified_date).format('YYYY-MM-DD HH:mm') : "";
                row.append($("<td>").text(uploaded));
                var insertBtn = $("<button class='btn btn-primary btn-sm'>Insert</button>");
                insertBtn.on("click", function () {
                    insertVideoIntoEditor(v.Id || v.id, v.name); // 서버 모델에 따라 Id 또는 id 사용
                    $("#videoPickerModal").modal("hide");
                });
                row.append($("<td>").append(insertBtn));
                $("#videoPickerTable tbody").append(row);
            });
        })
        .error(function () {
            $("#videoPickerLoading").hide();
            modalError("Error fetching videos");
        });
}

// CKEditor에 비디오 태그 + 시청 트래커 삽입
function insertVideoIntoEditor(videoId, videoName) {
    // 기본 삽입 HTML — /media/{id} 엔드포인트를 사용
    // rid는 수신자 링크에서 들어오기 때문에 런타임에 제공됩니다.
    // 여기선 rid를 쿼리스트링에서 가져가도록 스크립트를 포함합니다.
    var html = '\
<div class="gophish-training-video">\
  <h4>' + escapeHtml(videoName || "Training Video") + '</h4>\
  <video id="gophish-training-video-' + videoId + '" controls style="width:100%; max-width:100%;">\
    <source src="/media/' + videoId + '" type="video/mp4">\
    Your browser does not support the video tag.\
  </video>\
  <script>(function(){\
    var v=document.getElementById("gophish-training-video-' + videoId + '");\
    if(!v) return;\
    var params=new URLSearchParams(window.location.search);var rid=params.get("rid")||params.get("RID")||\"\";\
    function sendEvent(e){ try{ var payload={rid:rid,video_id:' + videoId + ',event:e,currentTime:Math.floor(v.currentTime||0),duration:Math.floor(v.duration||0)}; var b=new Blob([JSON.stringify(payload)],{type:"application/json"}); navigator.sendBeacon("/track/video",b);}catch(ex){} }\
    v.addEventListener("timeupdate",function(){ if((v.currentTime|0)%5===0) sendEvent("progress"); });\
    v.addEventListener("play",function(){sendEvent("play");});\
    v.addEventListener("ended",function(){sendEvent("ended");});\
    window.addEventListener("beforeunload",function(){sendEvent("unload");});\
  })();</script>\
</div>';

    // CKEditor 인스턴스가 있으면 HTML 탭에 삽입
    try {
        var editor = CKEDITOR.instances["html_editor"];
        if (editor) {
            editor.insertHtml(html);
            // 편집기 모드를 WYSIWYG로 전환
            editor.setMode('wysiwyg');
            // 포커스
            editor.focus();
            successFlash("Inserted training video into page");
        } else {
            // textarea 직접 사용중이면 append
            var ta = document.getElementById("html_editor");
            if (ta) {
                ta.value = ta.value + "\n" + html;
                successFlash("Inserted training video into page (textarea)");
            }
        }
    } catch (e) {
        console.error(e);
        modalError("Failed to insert video into editor");
    }
}

