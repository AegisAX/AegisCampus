/*
	landing_pages.js
	Handles the creation, editing, and deletion of landing pages
	Author: Jordan Wright <github.com/jordan-wright>
*/
var pages = []


// Save attempts to POST to /templates/
function save(idx) {
    var page = {}
    page.name = $("#name").val()
    editor = CKEDITOR.instances["html_editor"]
    page.html = editor.getData()
    page.capture_credentials = $("#capture_credentials_checkbox").prop("checked")
    page.capture_passwords = $("#capture_passwords_checkbox").prop("checked")
    page.redirect_url = $("#redirect_url_input").val()
    if (idx != -1) {
        page.id = pages[idx].id
        api.pageId.put(page)
            .success(function (data) {
                successFlash("Page edited successfully!")
                load()
                dismiss()
            })
    } else {
        // Submit the page
        api.pages.post(page)
            .success(function (data) {
                successFlash("Page added successfully!")
                load()
                dismiss()
            })
            .error(function (data) {
                modalError(data.responseJSON.message)
            })
    }
}

function dismiss() {
    $("#modal\\.flashes").empty()
    $("#name").val("")
    $("#html_editor").val("")
    $("#url").val("")
    $("#redirect_url_input").val("")
    $("#modal").find("input[type='checkbox']").prop("checked", false)
    $("#capture_passwords").hide()
    $("#redirect_url").hide()
    $("#modal").modal('hide')
}

var deletePage = function (idx) {
    Swal.fire({
        title: "Are you sure?",
        text: "This will delete the landing page. This can't be undone!",
        type: "warning",
        animation: false,
        showCancelButton: true,
        confirmButtonText: "Delete " + escapeHtml(pages[idx].name),
        confirmButtonColor: "#428bca",
        reverseButtons: true,
        allowOutsideClick: false,
        preConfirm: function () {
            return new Promise(function (resolve, reject) {
                api.pageId.delete(pages[idx].id)
                    .success(function (msg) {
                        resolve()
                    })
                    .error(function (data) {
                        reject(data.responseJSON.message)
                    })
            })
        }
    }).then(function (result) {
        if (result.value){
            Swal.fire(
                'Landing Page Deleted!',
                'This landing page has been deleted!',
                'success'
            );
        }
        $('button:contains("OK")').on('click', function () {
            location.reload()
        })
    })
}

function importSite() {
    url = $("#url").val()
    if (!url) {
        modalError("No URL Specified!")
    } else {
        api.clone_site({
                url: url,
                include_resources: false
            })
            .success(function (data) {
                $("#html_editor").val(data.html)
                CKEDITOR.instances["html_editor"].setMode('wysiwyg')
                $("#importSiteModal").modal("hide")
            })
            .error(function (data) {
                modalError(data.responseJSON.message)
            })
    }
}

function edit(idx) {
    $("#modalSubmit").unbind('click').click(function () {
        save(idx)
    })
    $("#html_editor").ckeditor()
    setupAutocomplete(CKEDITOR.instances["html_editor"])
    var page = {}
    if (idx != -1) {
        $("#modalLabel").text("Edit Landing Page")
        page = pages[idx]
        $("#name").val(page.name)
        $("#html_editor").val(page.html)
        $("#capture_credentials_checkbox").prop("checked", page.capture_credentials)
        $("#capture_passwords_checkbox").prop("checked", page.capture_passwords)
        $("#redirect_url_input").val(page.redirect_url)
        if (page.capture_credentials) {
            $("#capture_passwords").show()
            $("#redirect_url").show()
        }
    } else {
        $("#modalLabel").text("New Landing Page")
    }
}

function copy(idx) {
    $("#modalSubmit").unbind('click').click(function () {
        save(-1)
    })
    $("#html_editor").ckeditor()
    var page = pages[idx]
    $("#name").val("Copy of " + page.name)
    $("#html_editor").val(page.html)
}

function load() {
    /*
        load() - Loads the current pages using the API
    */
    $("#pagesTable").hide()
    $("#emptyMessage").hide()
    $("#loading").show()
    api.pages.get()
        .success(function (ps) {
            pages = ps
            $("#loading").hide()
            if (pages.length > 0) {
                $("#pagesTable").show()
                pagesTable = $("#pagesTable").DataTable({
                    destroy: true,
                    columnDefs: [{
                        orderable: false,
                        targets: "no-sort"
                    }]
                });
                pagesTable.clear()
                pageRows = []
                $.each(pages, function (i, page) {
                    pageRows.push([
                        escapeHtml(page.name),
                        moment(page.modified_date).format('MMMM Do YYYY, h:mm:ss a'),
                        "<div class='pull-right'><span data-toggle='modal' data-backdrop='static' data-target='#modal'><button class='btn btn-primary' data-toggle='tooltip' data-placement='left' title='Edit Page' onclick='edit(" + i + ")'>\
                    <i class='fa fa-pencil'></i>\
                    </button></span>\
		    <span data-toggle='modal' data-target='#modal'><button class='btn btn-primary' data-toggle='tooltip' data-placement='left' title='Copy Page' onclick='copy(" + i + ")'>\
                    <i class='fa fa-copy'></i>\
                    </button></span>\
                    <button class='btn btn-danger' data-toggle='tooltip' data-placement='left' title='Delete Page' onclick='deletePage(" + i + ")'>\
                    <i class='fa fa-trash-o'></i>\
                    </button></div>"
                    ])
                })
                pagesTable.rows.add(pageRows).draw()
                $('[data-toggle="tooltip"]').tooltip()
            } else {
                $("#emptyMessage").show()
            }
        })
        .error(function () {
            $("#loading").hide()
            errorFlash("Error fetching pages")
        })
}

$(document).ready(function () {
    // Setup multiple modals
    // Code based on http://miles-by-motorcycle.com/static/bootstrap-modal/index.html
    $('.modal').on('hidden.bs.modal', function (event) {
        $(this).removeClass('fv-modal-stack');
        $('body').data('fv_open_modals', $('body').data('fv_open_modals') - 1);
    });
    $('.modal').on('shown.bs.modal', function (event) {
        // Keep track of the number of open modals
        if (typeof ($('body').data('fv_open_modals')) == 'undefined') {
            $('body').data('fv_open_modals', 0);
        }
        // if the z-index of this modal has been set, ignore.
        if ($(this).hasClass('fv-modal-stack')) {
            return;
        }
        $(this).addClass('fv-modal-stack');
        // Increment the number of open modals
        $('body').data('fv_open_modals', $('body').data('fv_open_modals') + 1);
        // Setup the appropriate z-index
        $(this).css('z-index', 1040 + (10 * $('body').data('fv_open_modals')));
        $('.modal-backdrop').not('.fv-modal-stack').css('z-index', 1039 + (10 * $('body').data('fv_open_modals')));
        $('.modal-backdrop').not('fv-modal-stack').addClass('fv-modal-stack');
    });
    $.fn.modal.Constructor.prototype.enforceFocus = function () {
        $(document)
            .off('focusin.bs.modal') // guard against infinite focus loop
            .on('focusin.bs.modal', $.proxy(function (e) {
                if (
                    this.$element[0] !== e.target && !this.$element.has(e.target).length
                    // CKEditor compatibility fix start.
                    &&
                    !$(e.target).closest('.cke_dialog, .cke').length
                    // CKEditor compatibility fix end.
                ) {
                    this.$element.trigger('focus');
                }
            }, this));
    };
    // Scrollbar fix - https://stackoverflow.com/questions/19305821/multiple-modals-overlay
    $(document).on('hidden.bs.modal', '.modal', function () {
        $('.modal:visible').length && $(document.body).addClass('modal-open');
    });
    $('#modal').on('hidden.bs.modal', function (event) {
        dismiss()
    });
    $("#capture_credentials_checkbox").change(function () {
        $("#capture_passwords").toggle()
        $("#redirect_url").toggle()
    })
    CKEDITOR.on('dialogDefinition', function (ev) {
        // Take the dialog name and its definition from the event data.
        var dialogName = ev.data.name;
        var dialogDefinition = ev.data.definition;

        // Check if the definition is from the dialog window you are interested in (the "Link" dialog window).
        if (dialogName == 'link') {
            dialogDefinition.minWidth = 500
            dialogDefinition.minHeight = 100

            // Remove the linkType field
            var infoTab = dialogDefinition.getContents('info');
            infoTab.get('linkType').hidden = true;
        }
    });

    load()
})

/* === Video Picker Integration for Landing Pages === */

// 호출: "Insert Training Video" 버튼 클릭 시
function showVideoPicker() {
    // Open modal and load videos
    $("#videoPickerModal").modal("show");
    loadVideoPicker();
}

function loadVideoPicker() {
    $("#videoPickerLoading").show();
    $("#videoPickerTable").hide();
    $("#videoPickerEmpty").hide();
    $("#videoPickerTable tbody").empty();

    api.videos.get()
        .success(function (videos) {
            $("#videoPickerLoading").hide();
            if (!Array.isArray(videos) || videos.length === 0) {
                $("#videoPickerEmpty").show();
                return;
            }
            $("#videoPickerTable").show();
            videos.forEach(function (v) {
                var row = $("<tr>");
                row.append($("<td>").text(v.name));
                var uploaded = v.modified_date ? moment(v.modified_date).format('YYYY-MM-DD HH:mm') : "";
                row.append($("<td>").text(uploaded));
                var insertBtn = $("<button class='btn btn-primary btn-sm'>Insert</button>");
                insertBtn.on("click", function () {
                    insertTrainingTemplate(v.Id || v.id, v.name); // 서버 모델에 따라 Id 또는 id 사용
                    $("#videoPickerModal").modal("hide");
                });
                row.append($("<td>").append(insertBtn));
                $("#videoPickerTable tbody").append(row);
            });
        })
        .error(function () {
            $("#videoPickerLoading").hide();
            modalError("Error fetching videos");
        });
}

// CKEditor에 "완성된 학습용 랜딩 페이지" 템플릿을 통으로 세팅
// videoId: 선택한 등록 비디오의 ID (서버 모델에 따라 v.Id 또는 v.id를 전달)
// videoName: UI 표시용 제목(헤더/본문에 반영)
function insertTrainingTemplate(videoId, videoName) {
  // 이미 내용이 있다면 덮어쓸지 확인
  var editor = CKEDITOR.instances["html_editor"];
  var hasContent = false;
  try {
    if (editor) {
      hasContent = (editor.getData() || "").trim().length > 0;
    } else {
      var ta = document.getElementById("html_editor");
      hasContent = ta && (ta.value || "").trim().length > 0;
    }
  } catch (_) {}

  if (hasContent) {
    if (!confirm("현재 내용을 모두 교체하고 학습용 템플릿을 삽입할까요?")) {
      return;
    }
  }

  // 요청하신 전체 HTML 템플릿
  // - /media/{videoId} 로 재생 (관리자에서 업로드한 파일과 연결)
  // - rid는 쿼리스트링에서 가져와 /track/video 로 sendBeacon
  // - 진행률 표시 및 완료 버튼 활성화 포함
  var safeTitle = (videoName || "사이버보안 인식 제고 교육").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  var html = [
'<!DOCTYPE html>',
'<html lang="ko">',
'<head>',
'  <meta charset="UTF-8">',
'  <title>' + safeTitle + '</title>',
'  <meta name="viewport" content="width=device-width, initial-scale=1">',
'  <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" rel="stylesheet">',
'  <style>',
'    body { background: #f7f9fc; }',
'    header { background:#0f2743; color:#fff; padding:15px; text-align:center; }',
'    .container-box { max-width:960px; margin:30px auto; background:#fff; padding:25px; border-radius:12px; box-shadow:0 6px 18px rgba(0,0,0,0.08);}',
'    #training-video { width:100%; border-radius:8px; box-shadow:0 4px 12px rgba(0,0,0,0.2);}',
'    #progress-bar { height:22px; line-height:22px; }',
'    .btn-complete { margin-top:20px; }',
'  /* ↓↓↓ 다운로드/ PiP 억제용 추가 CSS */',
'  video::-internal-media-controls-download-button { display: none; }',
'  video::-webkit-media-controls-enclosure { overflow: hidden; }',
'  video::-webkit-media-controls-picture-in-picture-button { display: none; }',
'  </style>',
'</head>',
'<body>',
'  <header>',
'    <h2><i class="glyphicon glyphicon-education"></i>사이버보안 인식 제고 교육</h2>',
'  </header>',
'  <div class="container-box">',
'    <video id="training-video" controls playsinline disablePictureInPicture controlsList="nodownload noplaybackrate" oncontextmenu="return false">',
'      <!-- Gophish Media endpoint: /media/{video_id} -->',
'      <source src="/media/' + videoId + '" type="video/mp4">',
'      지원되지 않는 브라우저입니다.',
'    </video>',
'    <br><span style="font-size:18px;">' + safeTitle + '</span><br>',
'',
'    <div class="progress" style="margin-top:20px;">',
'      <div id="progress-bar" class="progress-bar progress-bar-success" role="progressbar" style="width:0%">0%</div>',
'    </div>',
'',
'    <span style="font-size:18px;">* 교육 수강 완료 후 반드시 아래 <strong>수강 완료 확인</strong> 버튼을 클릭하셔야만 교육 수강 완료 처리가 됩니다.</span>',
'    <button id="complete-btn" class="btn btn-success btn-lg btn-block btn-complete" disabled>',
'      수강 완료 확인',
'    </button>',
'  </div>',
'',
'  <script>',
'    // ------------------------------',
'    // 학습 진행률 기록 + Beacon 전송 + 시킹 차단',
'    // ------------------------------',
'    var v = document.getElementById("training-video");',
'    var bar = document.getElementById("progress-bar");',
'    var completeBtn = document.getElementById("complete-btn");',
'    var params = new URLSearchParams(window.location.search);',
'    var rid = params.get("rid") || params.get("RID") || "";',
'    var videoId = ' + videoId + ';',
'',
'    // 허용된 최대 시각(자연 재생으로만 증가)',
'    var allowedMax = 0;',
'    var clampBusy = false; // 루프 방지',
'    var EPS = 0.25;        // 허용 오차',
'',
'    function clampForwardSeek(){',
'      if (clampBusy) return;',
'      if (v.currentTime > allowedMax + EPS) {',
'        clampBusy = true;',
'        v.currentTime = allowedMax;  // 앞으로 감기 원복',
'        // 재생 상태 유지',
'        var wasPaused = v.paused;',
'        if (!wasPaused) v.play().catch(function(){});',
'        clampBusy = false;',
'      }',
'    }',
'',
'    // 진행률/표시/비콘',
'    function updateProgressAndBeacon(){',
'      if (!v.duration) return;',
'      var percent = (v.currentTime / v.duration) * 100;',
'      bar.style.width = percent.toFixed(1) + "%";',
'      bar.innerText = percent.toFixed(0) + "%";',
'      // 5초마다 누적 전송',
'      if (((v.currentTime|0) % 5) === 0) sendProgress("progress");',
'    }',
'',
'    function sendProgress(eventName) {',
'      if (!rid) return;',
'      try {',
'        var payload = {',
'          rid: rid,',
'          video_id: videoId,',
'          event: eventName,',
'          currentTime: Math.floor(v.currentTime || 0),',
'          duration: Math.floor(v.duration || 0)',
'        };',
'        var blob = new Blob([JSON.stringify(payload)], { type: "application/json" });',
'        navigator.sendBeacon("/track/video", blob);',
'      } catch (e) {}',
'    }',
'',
'    // 메타데이터 로드 후 초기화',
'    v.addEventListener("loadedmetadata", function(){',
'      allowedMax = 0;',
'      clampForwardSeek();',
'    });',
'',
'    // 자연 재생 중에는 allowedMax를 올리고,',
'    // 불법 앞으로 감기 시도는 즉시 되돌림',
'    v.addEventListener("timeupdate", function(){',
'      if (!v.seeking && !clampBusy) {',
'        if (v.currentTime > allowedMax) allowedMax = v.currentTime;',
'      }',
'      clampForwardSeek();',
'      updateProgressAndBeacon();',
'    });',
'',
'    // 드래그/키 시킹 즉시 차단',
'    v.addEventListener("seeking", clampForwardSeek);',
'    v.addEventListener("seeked",  clampForwardSeek);',
'',
'    v.addEventListener("play",  function(){ sendProgress("play");  });',
'    v.addEventListener("pause", function(){ sendProgress("pause"); });',
'    v.addEventListener("ended", function(){',
'      sendProgress("ended");',
'      completeBtn.disabled = false;',
'    });',
'',
'    completeBtn.addEventListener("click", function(){',
'      alert("수강 완료가 확인되었습니다. 감사합니다!");',
'    });',
'',
'    window.addEventListener("beforeunload", function(){',
'      sendProgress("unload");',
'    });',
'  </script>',
'</body>',
'</html>'
  ].join("\n");

  try {
    if (editor) {
      editor.setData(html);         // 전체 페이지로 교체
      editor.setMode('wysiwyg');
      editor.focus();
    } else {
      var ta2 = document.getElementById("html_editor");
      if (ta2) ta2.value = html;
    }
    successFlash("학습용 랜딩 페이지 템플릿을 삽입했습니다.");
  } catch (e) {
    console.error(e);
    modalError("템플릿 삽입에 실패했습니다.");
  }
}

